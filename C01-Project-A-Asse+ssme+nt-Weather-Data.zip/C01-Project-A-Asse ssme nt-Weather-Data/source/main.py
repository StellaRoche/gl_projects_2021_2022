from model import UserModel, DeviceModel, WeatherDataModel,AccessModel,DailyReportsModel
from datetime import datetime
from datetime import date
user_coll = UserModel()
device_coll = DeviceModel()
weather_data_coll = WeatherDataModel()
access_coll = AccessModel()
daily_reports_coll=DailyReportsModel()


# creating options
try:
    while True:
        print("\n***************WEATHER MODEL MAIN MENU******************")
        print("1. Insert Options")
        print("2. Read Options")
        print("3. Update Options")
        print("4. Delete Options")
        print("5.Exit")
        choice1 = int(input("\n\nEnter your Choice for the type of operation you desire:"))

        if choice1 == 1:
            print("\nINSERT DATA")
            print("1. New User")
            print("2. New Device")
            print("3. New Access privilege")
            print("4. New Weather Data")
            print("5. New Report")
            print("6. Exit")
            choice2 = int(input("\n\nEnter the Choice for the type of data you want to insert:"))

            if choice2 == 1:

                try:
                    # An attempt  to insert a user
                    print("\nInserting new user option")
                    username = (input("\nEnter your name :")).lower()
                    user_document = user_coll.find_by_username(username)
                    role = user_document["role"]
                    if (role != 'admin'):
                        print("\nSorry, you cannot enter the details.Please contact admin \n\n\n")
                    else:
                        username = (input("\nEnter user name ")).lower()
                        user_document = user_coll.find_by_username(username)
                        if (user_document):
                            print("\nUser already exists")
                        else:
                            email = (input("Enter email ")).lower()
                            role = (input("Enter role in lower case")).lower()
                            user_document = user_coll.insert(username, email, role)
                            if (user_document == -1):
                                print(user_coll.latest_error)
                            else:
                                print(user_document)
                                print("\n")
                except Exception as e:
                    print("An exception occurred::", e)

            elif choice2 == 2:
                print ("\nInsert New device data")
                try:
                    yourname = (input("\nEnter your name :")).lower()
                    user_document = user_coll.find_by_username(yourname)
                    role = user_document["role"]
                    if (role != 'admin'):
                        print("\nSorry, you cannot enter the details.Please contact admin \n\n\n")
                    else:
                        device_id=input("\nEnter device id for example- DT201 or DH505 :").upper()
                        desc= input("\nEnter description for example- Temperature sensor or Humidity sensor :")
                        type = input("\nEnter device type either - Temperature or Humidity :")
                        manufacturer = input("\nEnter device manufacturer for example- Acme :")
                        device_document = device_coll.insert(device_id,desc,type,manufacturer)
                        if (device_document == -1):
                            print(device_coll.latest_error)
                        else:
                            print(device_document)
                except Exception as e:
                    print("An exception occurred::", e)

            elif choice2 == 3:
                print("Insert New Access privilege")
                try:
                    yourname = (input("\nEnter your name :")).lower()
                    user_document = user_coll.find_by_username(yourname)# Searching for the document for the username received above
                    role = user_document["role"]#assigning the role of this user found in the user document to variable role
                    if (role != 'admin'):# checking if role is not admin, to restrict enabling access to anyone
                        print("\nSorry, you cannot enter the details.Please contact admin \n\n\n")
                    else:
                        accessname=(input("\nEnter user for whom access to be given")).lower()
                        user_document = user_coll.find_by_username(accessname)
                        if(user_document):
                            device_id= (input("\nEnter device id for which access to be given")).upper()
                            device_document = device_coll.find_by_device_id(device_id)
                            if (device_document):
                                useraccess=(input("\nEnter r or rw")).lower()
                                access_document = access_coll.find_access_by_username_device_id(accessname, device_id)
                                if(access_document): # if details already there checking
                                    print("\nSorry access details for this device already exists")
                                else:
                                    access1_document = access_coll.insert(accessname,device_id,useraccess)
                                    if access1_document:
                                        print(access1_document)
                                    else:
                                        print(access_coll.latest_error)
                            else:
                                print("\nSorry this device does not exist")
                        else:
                            print("\nSorry this user does not exist")

                except Exception as e:
                    print("\nAn exception occurred::", e)


            elif choice2 == 4:
                print("\nInsert New Weather Data")
                try:

                    yourname = input("\nEnter your name :").lower()
                    device_id=input("\nEnter device_id :").upper()
                    user_document = user_coll.find_by_username(yourname)
                    role = user_document["role"]
                    if (role != 'admin'):
                        access_document = access_coll.find_access_by_username_device_id(yourname, device_id)
                        if access_document:
                            access = access_document["useraccess"]
                            if access ==  'rw':
                                device_id = (input("\nEnter device id")).upper()
                                value = input("\nEnter device value")
                                timestamp = datetime(2020, 12, 2, 13, 30, 0)
                                weather_data_document = weather_data_coll.insert(device_id, value, timestamp)
                                if (weather_data_document == -1):
                                    print(weather_data_coll.latest_error)
                                else:
                                    print(weather_data_document)
                            else:
                                print("\nSorry you cannot enter,please contact admin")
                    else:
                        value = int(input("Enter device value"))
                        dyear=int(input ("enter year as yyyy"))
                        dmonth=int(input("Enter month as mm"))
                        dday=int(input("Enter day as d"))
                        timestamp = datetime( dyear,dmonth, dday, 13, 30, 0)
                        weather_data_document = weather_data_coll.insert(device_id, value, timestamp)
                        if (weather_data_document == -1):

                            print(weather_data_coll.latest_error)
                        else:
                            print(weather_data_document)

                except Exception as e:
                    print("An exception occurred::", e)










            elif choice2 == 5:
                print("\nInsert New Report")
                try:
                    yourname = (input("\nEnter your name :")).lower()
                    daily_reports_document = user_coll.find_by_username(yourname)
                    role = daily_reports_document["role"]
                    if (role != 'admin'):
                        print("\nSorry, you cannot enter the details.Please contact admin \n\n\n")

                    else:
                        pipeline = [{"$group": {
                            "_id": {'device_id': '$device_id',
                                    'day': {'$dateToString': {'format': '%Y-%m-%d', 'date': "$timestamp"}}},
                            'average_value': {"$avg": "$value"}, 'maximum_value': {"$max": "$value"},
                            'minimum_value': {"$min": "$value"}}}, {"$out": 'daily_reports'}]
                        m=daily_reports_coll.insert_daily_reports(weather_data_coll,pipeline)
                        print("\nReport created\n\n\n")

                except Exception as e:
                    print("An exception occurred::", e)

            elif choice2 == 6:
                print("\nLeaving Insert menu")
                break
            else:
                print("\nPlease enter the right choice for Inserting data.")

        elif choice1 == 2:
            print("\nREAD DATA MENU2")
            print("1. Read User data")
            print("2. Read Device data")
            print("3. Read Access privilege data")
            print("4. Read Weather Data")
            print("5. Read Report Data")
            print("Exit")
            choice3 = int(input("Enter the Choice:"))

            if choice3 == 1:
                print("\nSearching User data")
                print("1. Search by Username")
                print("2. Search by MongoDBId")
                print("3.Exit")
                choice4=int(input("\nEnter the Choice:"))
                if  choice4==1 :
                    print("\nSearch User data by Username")
                    try:
                        print("\n\nShows how to initiate and search in the users collection based on a username")
                        yourname = (input("Enter your name :")).lower()
                        user_document = user_coll.find_by_username(yourname)
                        role = user_document["role"]
                        if (role != 'admin'):
                            print("\nSorry, you cannot see the user details.Please contact admin \n\n\n")
                        else:
                            search_username = (input("\nEnter username you want to search :")).lower()
                            user_document = user_coll.find_by_username(search_username)
                            if (user_document):
                                print(user_document)
                            else:
                                print(user_coll.latest_error)
                    except Exception as e:
                        print("\nAn exception occurred::", e)

                elif choice4==2 :
                    print("\nSearch User data by MongoDBId")
                    try:
                        yourname = (input("\nEnter your name :")).lower()
                        user_document = user_coll.find_by_username(yourname)
                        role = user_document["role"]
                        if (role != 'admin'):
                            print("\nSorry, you cannot see the user details.Please contact admin \n\n\n")
                        else:
                            mongoDBid = input("\nEnter MongoDBid you want to search :")
                            user_document = user_coll.find_by_object_id(mongoDBid)
                            if (user_document):
                                print(user_document)
                            else:
                                print(user_coll.latest_error)
                    except Exception as e:
                        print("\nAn exception occurred::", e)
                elif choice4==3:
                    print("\nLeaving Search menu")
                    break
                else:
                    print("\nPlease enter correct choice for search menu.")




            elif choice3 == 2:
                print("\nSearching Device data")
                print("1. Search by Username and deviceId")
                print("2. Search by MongoDBId")
                print("3.Exit")
                choice5 = int(input("Enter the Choice:"))
                if choice5==1:
                    print("\nSearch Device Data by Username and device Id")
                    try:
                        print("\nShows how to initiate and search in the devices collection based on a device id\n")
                        yourname = (input("\nEnter your name :")).lower()
                        user_document = user_coll.find_by_username(yourname)
                        role = user_document["role"]
                        device_id = (input("\nEnter device_id to search")).upper()
                        print(device_id)
                        if (role == 'admin'):
                            print("after role")
                            device_document = device_coll.find_by_device_id(device_id)
                            if (device_document):
                                print(device_document)
                            else:
                                print(user_coll.latest_error)
                        else:
                            access_document = access_coll.find_access_by_username_device_id(yourname, device_id)

                            access = access_document["useraccess"]
                            if access == 'r' or access=='rw':
                                device_document = device_coll.find_by_device_id(device_id)
                                if (device_document):
                                    print(device_document)
                                else:
                                    print(user_coll.latest_error)
                            else:
                                    print("\nSorry you cannot access the device info, kindly contact admin")

                    except Exception as e:
                        print("An exception occurred::", e)
                elif choice5==2:
                    print("\nSearch Device Data by Device MongoDBId")
                    try:
                        yourname = (input("\nEnter your name :")).lower()
                        user_document = user_coll.find_by_username(yourname)
                        role = user_document["role"]
                        mongoDBid = input("\nEnter MongoDBid of device you want to search :")
                        if (role == 'admin'):
                            device_document = device_coll.find_by_device_object_id(mongoDBid)
                            if (device_document):
                                print(device_document)
                            else:
                                print(user_coll.latest_error)
                        else:
                            device_document = device_coll.find_by_device_object_id(mongoDBid)
                            if device_document:
                                device = device_document["device_id"]
                                access_document = access_coll.find_access_by_username_device_id(yourname, device)
                                if access_document:
                                    access = access_document["useraccess"]
                                    print (access)
                                    if access == 'r' or access=='rw':
                                        device_document = device_coll.find_by_device_object_id(mongoDBid)
                                        if (device_document):
                                            print(device_document)
                                        else:
                                            print(user_coll.latest_error)
                                else:
                                    print("\nYou are not authorized to view document.Kindly contact admin")
                    except Exception as e:
                        print("\nAn exception occurred::", e)
                elif choice5==3:
                    print("\nLeaving Search Device data")
                    break

                else:
                    print("\nPlease enter correct choice for searching device data")




            elif choice3 == 3:
                print("\nSearching Access privilege data")
                print("1. Search by Username")
                print("2. Search by MongoDBId")
                print("3. Search by DeviceId")
                print("4.Exit")
                choice6 = int(input("Enter the Choice:"))
                if choice6==1:
                    print("\nSearch access privilege by Username")
                    try:
                        yourname = input("\nEnter your name :").lower()
                        user_document = user_coll.find_by_username(yourname)
                        role = user_document["role"]
                        if (role != 'admin'):
                            print("\nSorry, you cannot see the access details.Please contact admin \n\n\n")
                        else:
                            search_username = input("\nEnter username you want to search :").lower()
                            user_document = user_coll.find_by_username(search_username)
                            if (user_document):
                                search_device_id=input("\nEnter device_id you want to search for access").upper()
                                device_document = device_coll.find_by_device_id(search_device_id)
                                if (device_document):
                                    access_document = access_coll.find_access_by_username_device_id(search_username, search_device_id)
                                    if (access_document):
                                        print(access_document)
                                    else:
                                        print(access_coll.latest_error)
                                else:
                                    print("\nSorry device does not exist")
                            else:
                                print("\nSorry user does not exist")
                    except Exception as e:
                        print("\nAn exception occurred::", e)

                elif choice6==2:
                    print("\nSearch access privilege by access MongoDBId")
                    try:
                        yourname = (input("\nEnter your name :")).lower()
                        user_document = user_coll.find_by_username(yourname)
                        role = user_document["role"]
                        mongoDBid = input("\nEnter MongoDBid of access you want to search :")

                        if (role == 'admin'):
                            access_document = access_coll.find_access_by_object_id(mongoDBid)

                            if (access_document):
                                print(access_document)

                            else:
                                print(access_coll.latest_error)

                        else:
                            print("\nYou are not authorized to view document.Kindly contact admin")

                    except Exception as e:
                        print("\nAn exception occurred::", e)

                elif choice6==3:
                    print(" \nSearch access privilege by DeviceId to be added soon")

                elif choice6==4:
                    print("\nLeaving searching access privilege data menu")
                    break
                else:
                    print("\nPlease enter correct choice searching access privilege")



            elif choice3 == 4:
                print("\nSearching Weather data")
                print("1. Search by Username and timestamp")
                print("2. Search by MongoDBId")
                print("3. Search by DeviceId")
                print("4.Exit")
                chSearchWdata = int(input("Enter the Choice:"))
                if  chSearchWdata==1:
                    print("\nSearch weatherdata by Username and timestamp")
                    try:
                        yourname = (input("\nEnter your name :")).lower()
                        device_id = (input("\nEnter device for which you want to see weather data :")).upper()
                        user_document = user_coll.find_by_username(yourname)
                        role = user_document["role"]
                        if (role != 'admin'):
                            access_document = access_coll.find_access_by_username_device_id(yourname, device_id)
                            if access_document:
                                access = access_document["useraccess"]
                                if access == 'r' or access=='rw':
                                    wyear=int(input("\nEnter year as yyyy format"))
                                    wmonth = int(input("Enter month as m format"))
                                    wday = int(input("Enter day as d format"))
                                    whour = int(input("Enter year as h format"))
                                    wmin = int(input("Enter year as M format"))
                                    wsec = int(input("Enter year as S format"))
                                    entry_day=datetime(wyear,wmonth,wday, whour,wmin, wsec)
                                    weather_data_document = weather_data_coll.find_by_device_id_and_timestamp(device_id,entry_day)
                                    if (weather_data_document):
                                        print(weather_data_document)
                                    else:
                                        print(weather_data_coll.latest_error)
                        else:

                            wyear = int(input("\nEnter year as yyyy format"))
                            wmonth = int(input("Enter month as m format"))
                            wday = int(input("Enter day as d format"))
                            whour = int(input("Enter year as h format"))
                            wmin = int(input("Enter year as M format"))
                            wsec = int(input("Enter year as S format"))
                            entry_day = datetime(wyear, wmonth, wday, whour, wmin, wsec)
                            weather_data_document = weather_data_coll.find_by_device_id_and_timestamp(device_id,
                                                                                                      entry_day)
                            if (weather_data_document):
                                print(weather_data_document)
                            else:
                                print(weather_data_coll.latest_error)
                    except Exception as e:
                        print("\nAn exception occurred::", e)




                elif chSearchWdata == 2:
                    print("\nSearch weatherdata by MongoDBId")
                    try:
                        yourname = (input("\nEnter your name :")).lower()
                        user_document = user_coll.find_by_username(yourname)
                        role = user_document["role"]
                        mongoDBid = input("\nEnter MongoDBid of access you want to search :")

                        if (role == 'admin'):
                            weather_data_document = weather_data_coll.find_by_object_id(mongoDBid)

                            if (weather_data_document):
                                print(weather_data_document)

                            else:
                                print(weather_data_coll.latest_error)

                        else:
                            print("\nYou are not authorized to view document.Kindly contact admin")

                    except Exception as e:
                        print("\nAn exception occurred::", e)
                elif chSearchWdata == 3:
                    print("Search weatherdata by DeviceId will be added soon")
                elif chSearchWdata == 4:
                    print("Leaving search for weatherdata Menu")
                    break
                else:
                    print("Please enter correct choice for searching Weatherdata Menu")



            elif choice3 == 5:
                print("\nSearching Report data")
                print("1. Search for aggregate for range of days")
                print("2.Exit")
                choice8 = int(input("\nEnter the Choice:"))
                if choice8 == 1:
                    print(" \nSearch for aggregate for range of days")
                    begin = input("Enter begin date in yyyy-mm-dd form")
                    end = input("Enter end date in yyyy-mm-dd form")
                    st_date = ((datetime.strptime(begin, "%Y-%m-%d")).date())
                    end_date = ((datetime.strptime(end, "%Y-%m-%d")).date())
                    device_id=input("Device whose report to be viewed").upper()
                    query_st = {'daily_reports._id.day': {"$gte": st_date, "$lt": end_date}}



                    m=daily_reports_coll.find_from_daily_reports( query_st,st_date,end_date)
                    print (m)








                elif choice8 == 2:
                    print("\nLeaving search report data Menu")
                    break
                else:
                    print("\nPlease enter correct choice for searching Report data")

            elif choice3 == 6:
                print("\nLeaving reading data Menu")
                break

            else:
                print("\nPlease enter correct choice for reading data.")
        elif choice1 == 3:
            print("\nupdate features to be added soon")
        elif choice1 == 4:
            print("\ndelete features to be added soon")
        elif choice1 == 5:
            print("\nLeaving Main Menu")
            break
        else:
            print("\nPlease enter correct choice for Main Menu")
except Exception as e:
    print("\nAn exception occurred::", e)











