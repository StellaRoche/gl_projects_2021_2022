import pymongo
from datetime import datetime,date

myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["weather_db"]
mycol = mydb["weather_data"]


s=[{"$group":{"_id":{'device_id':'$device_id','day':{'$dateToString':{'format':'%Y-%m-%d','date':"$timestamp"}}},'Average': {"$avg":"$value"},'Max':{"$max":"$value"},'Minimum':{"$min":"$value"}} },{ "$out" : "weather_db.dr_data" }]

pipeline=r
pipeline1=r
n=list(mycol.aggregate(pipeline))
for item in n:
    print(item)
   
mycol2="weather_db.dr_data"
#m=mycol2.find( [ {"device_id"=="DT002" }])
#for item in m:
    #print(item)
#mycol2.find( { 'device_id' : { "$eq": 'DT001' } } )
#mycol2.find({"_id.device_id": "DT002", "_id.day": "2020-12-02" })
'''
mycol2 =["weather_db.dr_data"]
device_id='DT001'
d='2020-12-01'

reports_document = mycol2.find_report_by_device_id_date(device_id,d)
if(reports_document):
    print(device_document)
    '''